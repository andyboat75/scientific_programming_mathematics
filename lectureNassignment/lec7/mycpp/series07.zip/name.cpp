#include"name.hpp"

int main(){
    Name person;
    person.setFullName("Eric Nana Kwabena Asamoah");
    person.printName();
    return 0;
}